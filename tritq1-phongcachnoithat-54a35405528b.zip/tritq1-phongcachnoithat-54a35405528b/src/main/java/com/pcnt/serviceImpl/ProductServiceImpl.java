package com.pcnt.serviceImpl;

import com.pcnt.model.Product;
import com.pcnt.repository.ProductRepository;
import com.pcnt.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Override
    public List<Product> getAllProduct() {
        List<Product> products = productRepository.findAll();
        return products;
    }

    @Override
    public Product getOneProduct(int productId) {
        Product product = productRepository.getByProductId(productId);
        return product;
    }

    @Override
    public List<Product> getProductByType(String type) {
        List<Product> products = productRepository.getAllByType(type);
        return products;
    }
}
