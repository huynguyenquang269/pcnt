package com.pcnt.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.pcnt.model.NewPost;
import com.pcnt.repository.NewPostRepository;
import com.pcnt.service.NewPostService;

@Service
public class NewPostServiceImpl implements NewPostService{
	
	@Autowired
	private NewPostRepository newPostRepository;
	
	@Override
	public void saveNewPost(NewPost newPost) {
		newPostRepository.save(newPost);
	}

	@Override
	public Page<NewPost> getListNewPost(Pageable pageable) {
		return newPostRepository.findNewPosts(pageable);
	}

	@Override
	public NewPost getNewPostById(int id) {
		return newPostRepository.getOne(id);
	}
}
