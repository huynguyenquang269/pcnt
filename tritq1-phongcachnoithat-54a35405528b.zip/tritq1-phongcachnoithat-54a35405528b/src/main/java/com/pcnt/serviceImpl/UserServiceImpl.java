package com.pcnt.serviceImpl;

import com.pcnt.model.User;
import com.pcnt.repository.UserRepository;
import com.pcnt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public boolean checkEmail(String email) {
		if(userRepository.findByEmail(email) != null){
			return false;
		}
		return true;
	}

	@Override
	public boolean checkConfirmPassword(String password, String confirmPassword) {
		if(password.equals(confirmPassword)){
			return true;
		}
		return false;
	}

	@Override
	public boolean checkDateOfBirth(String dateOfBirth) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = format.parse(dateOfBirth);
		System.out.println((format.parse(format.format(new Date())).getTime() - date.getTime()) / (24 * 60 *60 *1000));
		if(((format.parse(format.format(new Date())).getTime() - date.getTime()) / (24 * 60 *60 *1000))> 10*365){
			return true;
		}
		return false;
	}
	
	
}
