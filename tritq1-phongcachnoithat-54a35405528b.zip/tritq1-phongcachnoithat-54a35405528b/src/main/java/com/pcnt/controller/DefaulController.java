package com.pcnt.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pcnt.model.NewPost;
import com.pcnt.service.NewPostService;

@Controller
public class DefaulController {
	@Autowired
	private NewPostService newPostService;
	
	@GetMapping(value = "/")
	public String getHomePage(){
		return "index";
	}

	@GetMapping(value = "/login")
	public String getLogin(){
		return "login";
	}


	@GetMapping(value = "/list-news")
	public String getListNews(Model model, @RequestParam(name = "page") Optional<Integer> page){
		Sort  sortable = Sort.by("dateCreated").descending();
		int currentPage = page.orElse(1);
		Pageable pageable = PageRequest.of(currentPage - 1, 8, sortable);
		List<NewPost> listNewPostFirst = new ArrayList<>();
		Page<NewPost> pageNewPost = newPostService.getListNewPost(pageable);
		for (NewPost newPost : pageNewPost) {
			if (listNewPostFirst.size() == 2) {
				break;
			} 
			
			listNewPostFirst.add(newPost);
			
		}
		
		int totalPages = pageNewPost.getTotalPages();
		if (totalPages > 0) {
			List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages).boxed().collect(Collectors.toList());
			model.addAttribute("pageNumbers", pageNumbers);
		}
		
		model.addAttribute("pageNewPost", pageNewPost);
		model.addAttribute("listNewPostFirst", listNewPostFirst);
		model.addAttribute("listNewPost", pageNewPost);
		return "list-news";

	}

	@GetMapping(value = "/contact")
	public String getContact(){
		return "contact";
	}

	@GetMapping(value = "/new-detail")
	public String getNewsDetail(Model model, @RequestParam(name = "id") int id){
		NewPost newPostById = newPostService.getNewPostById(id);
		model.addAttribute("newPost", newPostById);
		return "news";
	}

	@GetMapping(value = "/sanpham")
	public String getSanpham(){
		return "product";
	}
	

}
