package com.pcnt.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.pcnt.form.UploadForm;
import com.pcnt.model.NewPost;
import com.pcnt.service.NewPostService;

@Controller
public class UploadNewPostController {
	
	@Autowired
	private NewPostService newPostService;
	
    // GET: Hiển thị trang form upload
    @RequestMapping(value = "/add-news", method = RequestMethod.GET)
    public String uploadOneFileHandler(Model model) {

        UploadForm myUploadForm = new UploadForm();
        model.addAttribute("myUploadForm", myUploadForm);

        return "/add-news";
    }

    // POST: Sử lý Upload
    @RequestMapping(value = "/create-posts", method = RequestMethod.POST)
    public String uploadOneFileHandlerPOST(HttpServletRequest request, //
                                           Model model, //
                                           @ModelAttribute("myUploadForm") UploadForm myUploadForm) {
    	
        return this.doUpload(request, model, myUploadForm);

    }

    private String doUpload(HttpServletRequest request, Model model, //
                            UploadForm myUploadForm) {

        // Thư mục gốc upload file.
        String uploadRootPath = request.getServletContext().getRealPath("upload");

        File uploadRootDir = new File(uploadRootPath);
        // Tạo thư mục gốc upload nếu nó không tồn tại.
        if (!uploadRootDir.exists()) {
            uploadRootDir.mkdirs();
        }
        MultipartFile[] fileDatas = myUploadForm.getFileDatas();
        //
        List<File> uploadedFiles = new ArrayList<File>();
        List<String> failedFiles = new ArrayList<String>();

        MultipartFile fileData = fileDatas[0];

        // Tên file gốc tại Client.
        String name = fileData.getOriginalFilename();

        if (name != null && name.length() > 0) {
            try {
                // Tạo file tại Server.
                File serverFile = new File(uploadRootDir.getAbsolutePath() + File.separator + name);

                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
                stream.write(fileData.getBytes());
                stream.close();
                //
                uploadedFiles.add(serverFile);
                System.out.println("Write file: " + serverFile);
            } catch (Exception e) {
                System.out.println("Error Write file: " + name);
                failedFiles.add(name);
            }
        }

        NewPost newPost = new NewPost();
        newPost.setContent(myUploadForm.getDescription());
        newPost.setTitle(myUploadForm.getTitle());
        newPost.setImgLink("upload/" + name);
        newPost.setDateCreated(new Date());
        newPostService.saveNewPost(newPost);
        
        model.addAttribute("newPost", newPost);
        
        return "upload-result";
    }
}
