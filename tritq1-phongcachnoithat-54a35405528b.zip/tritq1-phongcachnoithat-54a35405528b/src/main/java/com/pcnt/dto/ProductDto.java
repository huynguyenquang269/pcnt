package com.pcnt.dto;

public class ProductDto {
}
