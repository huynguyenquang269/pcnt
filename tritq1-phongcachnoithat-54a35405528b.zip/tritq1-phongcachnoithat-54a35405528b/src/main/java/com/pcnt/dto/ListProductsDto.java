package com.pcnt.dto;

public class ListProductsDto {
}
