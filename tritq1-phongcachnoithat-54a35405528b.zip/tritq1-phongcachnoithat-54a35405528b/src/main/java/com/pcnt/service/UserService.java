package com.pcnt.service;

import java.text.ParseException;

public interface UserService {

	boolean checkConfirmPassword(String password, String confirmPassword);

	boolean checkEmail(String email);
	
	boolean checkDateOfBirth(String dateOfBirth) throws ParseException;
}
