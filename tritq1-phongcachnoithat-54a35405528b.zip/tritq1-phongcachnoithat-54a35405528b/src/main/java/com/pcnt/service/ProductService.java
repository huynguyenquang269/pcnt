package com.pcnt.service;

import com.pcnt.model.Product;

import java.util.List;

public interface ProductService {
    List<Product> getAllProduct();

    Product getOneProduct(int productId);

    List<Product> getProductByType(String type);
}
