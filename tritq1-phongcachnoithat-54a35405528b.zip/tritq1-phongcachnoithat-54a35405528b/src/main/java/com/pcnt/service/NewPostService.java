package com.pcnt.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.pcnt.model.NewPost;

public interface NewPostService {
	public void saveNewPost(NewPost newPost);
	
	public Page<NewPost> getListNewPost(Pageable pageable);
	
	public NewPost getNewPostById(int id);
}
